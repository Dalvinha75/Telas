// screens/DocumentsScreen.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList } from 'react-native';

export default function DocumentsScreen({ navigation }) {
  const docs = [
    { id: 'aula10', title: 'AULA 10 - Toolbar', file: 'aula10_toolbar.pdf' },
    { id: 'crud', title: 'CRUD com SQLite - Expo', file: 'crud_sqlite_expo.pdf' },
  ];

  function openDoc(file) {
    alert(`Abrir arquivo: ${file}\n\n(Local: assets/docs/${file})`);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Documentos</Text>

      <FlatList
        data={docs}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => openDoc(item.file)}
          >
            <Text style={styles.text}>{item.title}</Text>
            <Text style={styles.open}>Abrir</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
  item: {
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderColor: '#ccc',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  text: { fontSize: 16 },
  open: { color: '#007AFF' },
});
